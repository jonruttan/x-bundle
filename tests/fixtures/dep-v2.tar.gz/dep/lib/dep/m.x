(module dep/m)
(def m (fn (_) "dep v2"))
(provide dep/m m)
