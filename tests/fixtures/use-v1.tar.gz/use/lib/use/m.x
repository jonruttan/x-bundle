(module use/m)
(def m (fn (_) "use v1"))
(provide use/m m)
