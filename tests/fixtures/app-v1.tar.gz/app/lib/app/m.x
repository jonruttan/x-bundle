(module app/m)
(def m (fn (_) "app v1"))
(provide app/m m)
