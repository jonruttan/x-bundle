(module dep/m)
(def m (fn (_) "dep v3"))
(provide dep/m m)
